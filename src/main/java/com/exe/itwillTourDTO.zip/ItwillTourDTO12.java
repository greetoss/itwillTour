package com.exe.itwillTourDTO;

public class ItwillTourDTO12 {
	
	/*문의내역 변수 받는 DTO*/

	String search_select;
	String search_keyword;
	
	public String getSearch_select() {
		return search_select;
	}
	public void setSearch_select(String search_select) {
		this.search_select = search_select;
	}
	public String getSearch_keyword() {
		return search_keyword;
	}
	public void setSearch_keyword(String search_keyword) {
		this.search_keyword = search_keyword;
	}

	
	
	
	
}
